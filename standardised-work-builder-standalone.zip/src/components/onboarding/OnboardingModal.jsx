import React from 'react';
import { Button } from '@/components/ui/button';
import { X, CheckCircle2, PlayCircle, RotateCcw } from 'lucide-react';
import { useOnboarding } from '@/lib/onboardingContext';
import { TOURS, TOUR_ORDER } from '@/lib/onboardingTours';

export default function OnboardingModal({ onClose }) {
  const { startTour, completed, resetCompleted } = useOnboarding();

  const handleStart = (tourId) => {
    onClose();
    startTour(tourId);
  };

  return (
    <div className="fixed inset-0 z-[9999] flex items-center justify-center bg-black/50">
      <div className="bg-card border border-border rounded-2xl shadow-2xl w-full max-w-lg mx-4 overflow-hidden">
        {/* Header */}
        <div className="flex items-start justify-between p-6 border-b border-border">
          <div>
            <h2 className="text-lg font-semibold flex items-center gap-2">
              <span>🎓</span> Onboarding Tours
            </h2>
            <p className="text-sm text-muted-foreground mt-1">
              Step-by-step guided tours to get you up and running in under an hour.
            </p>
          </div>
          <button onClick={onClose} className="text-muted-foreground hover:text-foreground mt-0.5">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tours list */}
        <div className="p-4 space-y-3">
          {TOUR_ORDER.map(tourId => {
            const tour = TOURS[tourId];
            const isDone = completed.includes(tourId);
            return (
              <div key={tourId} className={`flex items-center gap-4 p-4 rounded-xl border transition-colors ${isDone ? 'border-border/50 bg-muted/30' : 'border-border bg-card hover:bg-muted/20'}`}>
                <div className="text-2xl shrink-0">{tour.icon}</div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <p className="text-sm font-medium text-foreground">{tour.label}</p>
                    {isDone && <CheckCircle2 className="w-3.5 h-3.5 text-chart-3" />}
                  </div>
                  <p className="text-xs text-muted-foreground mt-0.5 leading-relaxed">{tour.description}</p>
                  <p className="text-[11px] text-muted-foreground/60 mt-1">{tour.steps.length} steps</p>
                </div>
                <Button
                  size="sm"
                  variant={isDone ? 'outline' : 'default'}
                  onClick={() => handleStart(tourId)}
                  className="shrink-0 gap-1.5 h-8 text-xs"
                >
                  <PlayCircle className="w-3.5 h-3.5" />
                  {isDone ? 'Replay' : 'Start'}
                </Button>
              </div>
            );
          })}
        </div>

        {/* Footer */}
        <div className="px-4 pb-4 flex items-center justify-between">
          <button
            onClick={resetCompleted}
            className="text-xs text-muted-foreground hover:text-foreground flex items-center gap-1"
          >
            <RotateCcw className="w-3 h-3" /> Reset progress
          </button>
          <Button variant="ghost" size="sm" onClick={onClose} className="text-xs h-7">
            Close
          </Button>
        </div>
      </div>
    </div>
  );
}