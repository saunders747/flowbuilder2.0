import React, { useEffect, useState, useCallback, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { X, ChevronLeft, ChevronRight, CheckCircle2 } from 'lucide-react';
import { useOnboarding } from '@/lib/onboardingContext';
import { TOURS } from '@/lib/onboardingTours';

const PADDING = 12;

function getRect(selector) {
  if (!selector) return null;
  try {
    const el = document.querySelector(selector);
    if (!el) return null;
    const r = el.getBoundingClientRect();
    return { top: r.top, left: r.left, width: r.width, height: r.height };
  } catch { return null; }
}

function TooltipBox({ step, stepIndex, totalSteps, onNext, onPrev, onEnd, rect }) {
  const isFirst = stepIndex === 0;
  const isLast = stepIndex === totalSteps - 1;

  // Compute tooltip position
  let style = {};
  const tipW = 320;
  const tipH = 200; // approx
  const vw = window.innerWidth;
  const vh = window.innerHeight;

  if (!rect || step.placement === 'center') {
    style = {
      position: 'fixed',
      top: '50%',
      left: '50%',
      transform: 'translate(-50%, -50%)',
      width: tipW,
      zIndex: 10001,
    };
  } else {
    const p = step.placement;
    if (p === 'bottom') {
      style = {
        position: 'fixed',
        top: rect.top + rect.height + PADDING,
        left: Math.min(Math.max(8, rect.left + rect.width / 2 - tipW / 2), vw - tipW - 8),
        width: tipW,
        zIndex: 10001,
      };
    } else if (p === 'top') {
      style = {
        position: 'fixed',
        top: rect.top - tipH - PADDING,
        left: Math.min(Math.max(8, rect.left + rect.width / 2 - tipW / 2), vw - tipW - 8),
        width: tipW,
        zIndex: 10001,
      };
    } else if (p === 'right') {
      style = {
        position: 'fixed',
        top: Math.min(Math.max(8, rect.top + rect.height / 2 - tipH / 2), vh - tipH - 8),
        left: rect.left + rect.width + PADDING,
        width: tipW,
        zIndex: 10001,
      };
    } else if (p === 'left') {
      style = {
        position: 'fixed',
        top: Math.min(Math.max(8, rect.top + rect.height / 2 - tipH / 2), vh - tipH - 8),
        left: rect.left - tipW - PADDING,
        width: tipW,
        zIndex: 10001,
      };
    }
  }

  return (
    <div style={style} className="bg-card border border-border rounded-xl shadow-2xl p-4 space-y-3">
      {/* Header */}
      <div className="flex items-start justify-between gap-2">
        <h3 className="font-semibold text-sm text-foreground leading-tight">{step.title}</h3>
        <button onClick={onEnd} className="shrink-0 text-muted-foreground hover:text-foreground mt-0.5">
          <X className="w-4 h-4" />
        </button>
      </div>

      {/* Content */}
      <p className="text-xs text-muted-foreground leading-relaxed">{step.content}</p>

      {/* Action hint */}
      {step.action && (
        <div className="inline-flex items-center gap-1 bg-primary/10 text-primary text-[11px] font-medium px-2 py-1 rounded-full">
          <span>👆</span> {step.action}
        </div>
      )}

      {/* Footer */}
      <div className="flex items-center justify-between pt-1">
        <span className="text-[11px] text-muted-foreground">{stepIndex + 1} / {totalSteps}</span>
        <div className="flex items-center gap-1.5">
          {!isFirst && (
            <Button variant="ghost" size="sm" onClick={onPrev} className="h-7 px-2 text-xs gap-1">
              <ChevronLeft className="w-3 h-3" /> Back
            </Button>
          )}
          {isLast ? (
            <Button size="sm" onClick={onEnd} className="h-7 px-3 text-xs gap-1 bg-chart-3 hover:bg-chart-3/90 text-white">
              <CheckCircle2 className="w-3 h-3" /> Done
            </Button>
          ) : (
            <Button size="sm" onClick={onNext} className="h-7 px-3 text-xs gap-1">
              Next <ChevronRight className="w-3 h-3" />
            </Button>
          )}
        </div>
      </div>

      {/* Progress dots */}
      <div className="flex gap-1 justify-center">
        {Array.from({ length: totalSteps }).map((_, i) => (
          <div key={i} className={`h-1.5 rounded-full transition-all ${i === stepIndex ? 'w-4 bg-primary' : 'w-1.5 bg-muted-foreground/30'}`} />
        ))}
      </div>
    </div>
  );
}

export default function TourOverlay() {
  const { activeTour, stepIndex, endTour, nextStep, prevStep } = useOnboarding();
  const navigate = useNavigate();
  const [rect, setRect] = useState(null);
  const [visible, setVisible] = useState(false);
  const rafRef = useRef(null);

  const tour = activeTour ? TOURS[activeTour] : null;
  const step = tour ? tour.steps[stepIndex] : null;
  const totalSteps = tour ? tour.steps.length : 0;

  // Navigate if needed and find target element
  useEffect(() => {
    if (!step) { setVisible(false); return; }

    // Navigate to correct route
    if (step.route) navigate(step.route);
    else if (tour?.route) navigate(tour.route);

    // Poll for element up to 2s
    let attempts = 0;
    const maxAttempts = 40;
    const poll = () => {
      attempts++;
      const r = getRect(step.target);
      if (r) {
        setRect(r);
        setVisible(true);
      } else if (!step.target) {
        setRect(null);
        setVisible(true);
      } else if (attempts < maxAttempts) {
        rafRef.current = setTimeout(poll, 50);
      } else {
        setRect(null);
        setVisible(true); // show anyway centred
      }
    };
    setVisible(false);
    rafRef.current = setTimeout(poll, 150);
    return () => clearTimeout(rafRef.current);
  }, [step, stepIndex, activeTour]);

  const handleNext = useCallback(() => {
    if (stepIndex + 1 >= totalSteps) { endTour(true); }
    else nextStep(totalSteps);
  }, [stepIndex, totalSteps, nextStep, endTour]);

  if (!activeTour || !step || !visible) return null;

  // Spotlight rect
  const spotlightStyle = rect ? {
    top: rect.top - PADDING,
    left: rect.left - PADDING,
    width: rect.width + PADDING * 2,
    height: rect.height + PADDING * 2,
  } : null;

  return (
    <>
      {/* Dark backdrop with hole */}
      <div
        className="fixed inset-0 z-[10000] pointer-events-none"
        style={{
          background: spotlightStyle
            ? `radial-gradient(ellipse at ${spotlightStyle.left + spotlightStyle.width / 2}px ${spotlightStyle.top + spotlightStyle.height / 2}px, transparent ${Math.max(spotlightStyle.width, spotlightStyle.height) * 0.6}px, rgba(0,0,0,0.55) ${Math.max(spotlightStyle.width, spotlightStyle.height) * 0.75}px)`
            : 'rgba(0,0,0,0.5)',
        }}
      />

      {/* Spotlight border ring */}
      {spotlightStyle && (
        <div
          className="fixed z-[10000] rounded-lg border-2 border-primary pointer-events-none"
          style={{ ...spotlightStyle, boxShadow: '0 0 0 4px hsl(var(--primary)/0.2)' }}
        />
      )}

      {/* Tooltip */}
      <TooltipBox
        step={step}
        stepIndex={stepIndex}
        totalSteps={totalSteps}
        onNext={handleNext}
        onPrev={prevStep}
        onEnd={() => endTour(false)}
        rect={rect}
      />
    </>
  );
}