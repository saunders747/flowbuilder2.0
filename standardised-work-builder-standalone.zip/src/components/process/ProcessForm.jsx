import React, { useState, useEffect, useRef } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Save, X, Plus, Trash2, Upload, FileText, ChevronDown, ChevronUp } from 'lucide-react';
import { useFleet } from '@/hooks/useFleet';
import { useRoles } from '@/hooks/useRoles';
import { useSections } from '@/hooks/useSections';
import { toast } from 'sonner';
import * as XLSX from 'xlsx';
import { parseExcelWorkbook } from '@/lib/excelParser';
import { appClient } from '@/api/standaloneClient';

const FLEET_GROUPS = ['Haul Trucks','Excavators','Loaders','Graders','Dozers','Drills','Ancillary'];
const SERVICE_TYPES = ['Planned Maintenance','Servicing','Inspection','Shutdown','Component Changeout','Routine Maintenance'];
const STATUSES = ['Draft','Under Review','Approved for Trial','Approved Standard','Superseded'];
const STATE_TYPES = ['Current','Future','Trial','Approved Standard'];
const DEFAULT_LAYERS = [{ id: 'layer-ground', name: 'Ground Level', order: 0 }];

const defaultForm = {
  name: '', fleet_group: '', fleet_class: '', asset_model: '', asset_number: '',
  service_type: '', target_duration_hrs: '', safety_controls: '',
  required_tooling: '', required_parts: '', required_permits: '',
  version: 1, review_date: '', approval_status: 'Draft',
  review_notes: '', state_type: 'Current', is_template: false,
};

function Field({ label, field, type = 'text', span = 1, form, update }) {
  return (
    <div className={span === 2 ? 'col-span-2' : ''}>
      <Label className="text-xs font-medium text-muted-foreground">{label}</Label>
      <Input type={type} value={form[field] || ''} onChange={e => update(field, e.target.value)} className="mt-1" />
    </div>
  );
}

function SelectField({ label, field, options, form, update }) {
  return (
    <div>
      <Label className="text-xs font-medium text-muted-foreground">{label}</Label>
      <Select value={form[field] || ''} onValueChange={v => update(field, v)}>
        <SelectTrigger className="mt-1"><SelectValue placeholder={`Select ${label.toLowerCase()}`} /></SelectTrigger>
        <SelectContent>
          <SelectItem value={null}>— none —</SelectItem>
          {options.map(o => <SelectItem key={o} value={o}>{o}</SelectItem>)}
        </SelectContent>
      </Select>
    </div>
  );
}

export default function ProcessForm({ process, onSave, onCancel, isSaving }) {
  const { FLEET_CLASSES } = useFleet();
  const { roles } = useRoles();
  const { sections, addSection } = useSections();

  const [form, setForm] = useState(() => process ? { ...defaultForm, ...process } : { ...defaultForm });
  const [layers, setLayers] = useState(() => {
    if (process?.map_layers_data) { try { return JSON.parse(process.map_layers_data); } catch {} }
    return DEFAULT_LAYERS;
  });
  const [selectedSections, setSelectedSections] = useState(() => {
    if (process?.default_sections) { try { return JSON.parse(process.default_sections); } catch {} }
    return [];
  });
  const [defaultRole, setDefaultRole] = useState(process?.default_role || '');
  const [newLayerName, setNewLayerName] = useState('');
  const [newSection, setNewSection] = useState('');
  const [importFile, setImportFile] = useState(null);
  const [importing, setImporting] = useState(false);
  const [importPreview, setImportPreview] = useState(null);
  const [showAdvanced, setShowAdvanced] = useState(false);
  const fileRef = useRef(null);

  useEffect(() => { if (process) setForm({ ...defaultForm, ...process }); }, [process?.id]);

  const update = (field, value) => setForm(f => ({ ...f, [field]: value }));

  const addLayer = () => {
    const name = newLayerName.trim();
    if (!name) return;
    setLayers(l => [...l, { id: `layer-${Date.now()}`, name, order: l.length }]);
    setNewLayerName('');
  };
  const removeLayer = (id) => {
    if (layers.length <= 1) { toast.error('Must keep at least one layer'); return; }
    setLayers(l => l.filter(x => x.id !== id));
  };

  const toggleSection = (sec) =>
    setSelectedSections(prev => prev.includes(sec) ? prev.filter(s => s !== sec) : [...prev, sec]);

  const addNewSection = () => {
    const name = newSection.trim();
    if (!name) return;
    addSection(name);
    setSelectedSections(prev => [...prev, name]);
    setNewSection('');
  };

  const handleImportFile = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const isPdf = file.name.toLowerCase().endsWith('.pdf');
    const isCsv = file.name.toLowerCase().endsWith('.csv');

    const isExcel = /\.(xlsx|xls)$/i.test(file.name);
    if (!isPdf && !isCsv && !isExcel) {
      toast.error('Supported: PDF, Excel (.xlsx/.xls), CSV.');
      e.target.value = '';
      return;
    }
    if (isPdf && file.size > 10 * 1024 * 1024) {
      toast.error('PDF must be under 10 MB. Please compress or split the file first.');
      e.target.value = '';
      return;
    }

    setImportFile(file);
    setImporting(true);

    try {
      if (isPdf) {
        toast.info('Uploading PDF for AI extraction…');
        const { file_url } = await appClient.integrations.Core.UploadFile({ file });

        const result = await appClient.integrations.Core.InvokeLLM({
          prompt: `You are a process engineering assistant. Analyse this maintenance/work procedure PDF and extract ALL task steps.
For each step extract:
- step_number (sequential integer)
- task_description (full task text)
- role: ALWAYS return an empty string "" — the user assigns roles separately
- section (work phase if mentioned, e.g. Prepare, Service, Post Service)
- manual_time (labour time in minutes as a number, 0 if unknown)
- walking_time (travel time in minutes, 0 if unknown)
- waiting_time (waiting/idle time in minutes, 0 if unknown)
- machine_time (machine/auto time in minutes, 0 if unknown)
- inspection_time (inspection time in minutes, 0 if unknown)
- tool_time_category (category if identifiable, e.g. "tooltime::Tooltime - Planned Maint", else "")
- suggested_process_name (short descriptive name from the document title or content)
Return every distinct task step. Do not skip any. Set times to 0 if not given.`,
          file_urls: [file_url],
          response_json_schema: {
            type: 'object',
            properties: {
              suggested_process_name: { type: 'string' },
              rows: {
                type: 'array',
                items: {
                  type: 'object',
                  properties: {
                    step_number: { type: 'string' },
                    task_description: { type: 'string' },
                    role: { type: 'string' },
                    section: { type: 'string' },
                    manual_time: { type: 'number' },
                    walking_time: { type: 'number' },
                    waiting_time: { type: 'number' },
                    machine_time: { type: 'number' },
                    inspection_time: { type: 'number' },
                    tool_time_category: { type: 'string' },
                  },
                },
              },
            },
          },
        });

        if (result?.rows?.length > 0) {
          const validRoles = new Set(roles);
          setImportPreview(result.rows.map((r, i) => ({
            step_number: i + 1,
            task_description: r.task_description || '',
            role: validRoles.has(r.role) ? r.role : (defaultRole || ''),
            section: r.section || (selectedSections[0] || ''),
            manual_time: Number(r.manual_time) || 0,
            walking_time: Number(r.walking_time) || 0,
            waiting_time: Number(r.waiting_time) || 0,
            machine_time: Number(r.machine_time) || 0,
            inspection_time: Number(r.inspection_time) || 0,
            tool_time_category: r.tool_time_category || '',
          })));
          if (result.suggested_process_name && !form.name) {
            update('name', result.suggested_process_name);
          }
          toast.success(`Extracted ${result.rows.length} steps from PDF`);
        } else {
          toast.error('Could not extract steps from PDF — check the file is a readable text-based PDF');
          setImportFile(null);
        }
      } else if (isExcel) {
        // ── Excel structural parse (no AI) ──────────────────────────────
        toast.info('Reading Excel…');
        const buffer = await file.arrayBuffer();
        const { steps: excelSteps, sheets: parsedSheets, warnings } = parseExcelWorkbook(buffer);
        if (warnings.length) warnings.forEach(w => toast.warning(w));
        if (excelSteps.length === 0) {
          toast.error('No steps found in Excel. Check the file has "Task description" and "New Task No #" columns.');
          setImportFile(null); setImporting(false); return;
        }
        const validRoles = new Set(roles);
        setImportPreview(excelSteps.map(r => ({
          step_number:       r.step_number,
          task_description:  r.task_description,
          role:              validRoles.has(r.role) ? r.role : (defaultRole || ''),
          section:           r.section || (selectedSections[0] || ''),
          start_time:        r.start_time,
          manual_time:       r.manual_time,
          finish_time:       r.finish_time,
          walking_time:      r.walking_time || 0,
          waiting_time:      r.waiting_time || 0,
          machine_time:      r.machine_time || 0,
          inspection_time:   r.inspection_time || 0,
          tools_required:    r.tools_required || '',
          parts_required:    r.parts_required || '',
          tool_time_category: '',
        })));
        toast.success(`Extracted ${excelSteps.length} steps from ${parsedSheets.length} sheet${parsedSheets.length !== 1 ? 's' : ''}`);
      } else {
        // CSV parsing
        const text = await file.text();
        const lines = text.split('\n').filter(l => l.trim());
        const headers = lines[0].split(',').map(h => h.trim().toLowerCase().replace(/\s+/g, '_'));
        const rows = lines.slice(1).map(line => {
          const vals = line.split(',');
          return Object.fromEntries(headers.map((h, i) => [h, vals[i]?.trim() || '']));
        }).filter(r => r.task_description || r.task || r.description);
        if (rows.length === 0) {
          toast.error('No steps found. Check the CSV has a "task_description" column header.');
          setImportFile(null);
        } else {
          const validRoles = new Set(roles);
          setImportPreview(rows.map((r, i) => ({
            step_number: i + 1,
            task_description: r.task_description || r.task || r.description || '',
            role: validRoles.has(r.role) ? r.role : (defaultRole || ''),
            section: r.section || (selectedSections[0] || ''),
            manual_time: Number(r.manual_time || r.duration || 0),
            walking_time: Number(r.walking_time || 0),
            waiting_time: Number(r.waiting_time || 0),
            machine_time: Number(r.machine_time || 0),
            inspection_time: Number(r.inspection_time || 0),
            tool_time_category: r.tool_time_category || r.category || '',
          })));
          toast.success(`Parsed ${rows.length} steps from CSV`);
        }
      }
    } catch (err) {
      toast.error('Import failed: ' + (err?.message || 'unknown error'));
      setImportFile(null);
    } finally {
      setImporting(false);
      e.target.value = '';
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const data = { ...form };
    if (data.target_duration_hrs) data.target_duration_hrs = Number(data.target_duration_hrs);
    data.map_layers_data = JSON.stringify(layers);
    data.default_sections = JSON.stringify(selectedSections);
    data.default_role = defaultRole;
    onSave(data, true, importPreview);
  };

  return (
    <form onSubmit={handleSubmit}>
      <Card>
        <CardHeader className="pb-4">
          <CardTitle className="text-base">{process ? 'Edit Process' : 'New Process'}</CardTitle>
          {!process && <p className="text-xs text-muted-foreground mt-1">Click Save to create. After that, your changes will save automatically.</p>}
        </CardHeader>
        <CardContent className="space-y-6">

          {/* Process Identity */}
          <div>
            <h4 className="text-sm font-semibold mb-3">Process Identity</h4>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
              <div className="col-span-2">
                <Label className="text-xs font-medium text-muted-foreground">Process Name</Label>
                <Input value={form.name || ''} onChange={e => update('name', e.target.value)} className="mt-1" required />
              </div>
              <SelectField label="Fleet Group" field="fleet_group" options={FLEET_GROUPS} form={form} update={update} />
              <SelectField label="Fleet Class" field="fleet_class" options={FLEET_CLASSES || []} form={form} update={update} />
              <Field label="Asset Number" field="asset_number" form={form} update={update} />
              <SelectField label="Service Type" field="service_type" options={SERVICE_TYPES} form={form} update={update} />
            </div>
          </div>

          {/* Planning — target duration syncs to cycle time target */}
          <div>
            <h4 className="text-sm font-semibold mb-3">Planning</h4>
            <div className="max-w-xs">
              <Label className="text-xs font-medium text-muted-foreground">
                Target Duration (hrs)
                <span className="text-muted-foreground ml-1 font-normal">— sets cycle time target</span>
              </Label>
              <Input type="number" min={0} step={0.25} value={form.target_duration_hrs || ''} onChange={e => update('target_duration_hrs', e.target.value)} className="mt-1" />
            </div>
          </div>

          {/* Default Role */}
          <div>
            <h4 className="text-sm font-semibold mb-1">Default Role</h4>
            <p className="text-xs text-muted-foreground mb-2">Applied to imported steps with no role specified</p>
            <div className="flex flex-wrap gap-2">
              {roles.map(r => (
                <button key={r} type="button"
                  className={`px-3 py-1 rounded-full text-xs border transition-colors ${defaultRole === r ? 'bg-primary text-primary-foreground border-primary' : 'border-border hover:border-primary/50 text-muted-foreground'}`}
                  onClick={() => setDefaultRole(prev => prev === r ? '' : r)}>{r}</button>
              ))}
            </div>
          </div>

          {/* Sections */}
          <div>
            <h4 className="text-sm font-semibold mb-1">Sections</h4>
            <p className="text-xs text-muted-foreground mb-3">Select which sections apply to this process</p>
            <div className="flex flex-wrap gap-2 mb-3">
              {sections.map(s => (
                <button key={s} type="button"
                  className={`px-3 py-1 rounded-full text-xs border transition-colors ${selectedSections.includes(s) ? 'bg-primary text-primary-foreground border-primary' : 'border-border hover:border-primary/50 text-muted-foreground'}`}
                  onClick={() => toggleSection(s)}>{s}</button>
              ))}
            </div>
            <div className="flex gap-2">
              <Input placeholder="Add new section…" value={newSection} onChange={e => setNewSection(e.target.value)}
                onKeyDown={e => e.key === 'Enter' && (e.preventDefault(), addNewSection())}
                className="h-7 text-xs w-48" />
              <Button type="button" size="sm" variant="outline" className="h-7 text-xs" onClick={addNewSection}>
                <Plus className="w-3 h-3 mr-1" />Add
              </Button>
            </div>
          </div>

          {/* Spaghetti Map Layers */}
          <div>
            <h4 className="text-sm font-semibold mb-1">Spaghetti Map Layers</h4>
            <p className="text-xs text-muted-foreground mb-3">Define the physical levels of the workspace</p>
            <div className="space-y-2 mb-3">
              {layers.map((layer, idx) => (
                <div key={layer.id} className="flex items-center gap-2 p-2 bg-muted/30 rounded-md">
                  <span className="text-[10px] font-mono text-muted-foreground w-16 shrink-0">Layer {idx + 1}</span>
                  <span className="flex-1 text-sm">{layer.name}</span>
                  {idx > 0 && (
                    <button type="button" onClick={() => removeLayer(layer.id)} className="text-muted-foreground hover:text-destructive">
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              ))}
            </div>
            <div className="flex gap-2">
              <Input placeholder="New layer name…" value={newLayerName} onChange={e => setNewLayerName(e.target.value)}
                onKeyDown={e => e.key === 'Enter' && (e.preventDefault(), addLayer())}
                className="h-7 text-xs w-48" />
              <Button type="button" size="sm" variant="outline" className="h-7 text-xs" onClick={addLayer}>
                <Plus className="w-3 h-3 mr-1" />Add Layer
              </Button>
            </div>
          </div>

          {/* CSV Import */}
          <div>
            <h4 className="text-sm font-semibold mb-1">Import Steps (optional)</h4>
            <p className="text-xs text-muted-foreground mb-3">Upload a PDF (WIN, PMI, or Obzervr export — AI extracts steps automatically) or a CSV to pre-populate steps on process creation.</p>
            <input ref={fileRef} type="file" accept=".csv,.pdf" className="hidden" onChange={handleImportFile} />
            <div className="flex items-center gap-3">
              <Button type="button" variant="outline" size="sm" className="h-8 gap-2" onClick={() => fileRef.current?.click()} disabled={importing}>
                <Upload className="w-3.5 h-3.5" />{importing ? 'Processing…' : importFile ? 'Change file' : 'Upload PDF or CSV'}
              </Button>
              {importPreview && (
                <div className="flex items-center gap-2">
                  <FileText className="w-3.5 h-3.5 text-green-600" />
                  <span className="text-xs text-green-600 font-medium">{importPreview.length} steps ready</span>
                  <button type="button" onClick={() => { setImportFile(null); setImportPreview(null); }} className="text-muted-foreground hover:text-foreground"><X className="w-3.5 h-3.5" /></button>
                </div>
              )}
            </div>
            {importPreview?.length > 0 && (
              <div className="mt-3 border rounded-md overflow-hidden max-h-40 overflow-y-auto">
                <table className="w-full text-[10px]">
                  <thead className="bg-muted/50">
                    <tr>{['#','Section','Task','Role','Start','Dur','Fin'].map(h => <th key={h} className="px-2 py-1 text-left font-medium text-muted-foreground text-xs">{h}</th>)}</tr>
                  </thead>
                  <tbody>
                    {importPreview.slice(0,20).map((r,i) => (
                      <tr key={i} className={i%2===0?'bg-background':'bg-muted/20'}>
                        <td className="px-2 py-1 font-mono text-xs">{r.step_number}</td>
                        <td className="px-2 py-1 max-w-[100px] truncate text-xs text-muted-foreground">{r.section||'—'}</td>
                        <td className="px-2 py-1 max-w-[180px] truncate text-xs">{r.task_description}</td>
                        <td className="px-2 py-1 text-xs">{r.role||'—'}</td>
                        <td className="px-2 py-1 font-mono text-xs">{r.start_time!=null&&r.start_time!==''?r.start_time:'—'}</td>
                        <td className="px-2 py-1 font-mono text-xs font-semibold">{r.manual_time?`${r.manual_time}`:'0'}</td>
                        <td className="px-2 py-1 font-mono text-xs text-muted-foreground">{r.finish_time!=null&&r.finish_time!==''?r.finish_time:'—'}</td>
                      </tr>
                    ))}
                    {importPreview.length > 20 && <tr><td colSpan={7} className="px-2 py-1 text-center text-muted-foreground text-xs">…and {importPreview.length-20} more ({importPreview.length} total)</td></tr>}
                  </tbody>
                </table>
              </div>
            )}
          </div>

          {/* Requirements & Governance — collapsible */}
          <div>
            <button type="button" onClick={() => setShowAdvanced(v => !v)}
              className="flex items-center gap-2 text-sm font-semibold text-muted-foreground hover:text-foreground transition-colors">
              {showAdvanced ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
              Requirements & Governance
            </button>
            {showAdvanced && (
              <div className="mt-4 space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {[['Safety Controls','safety_controls'],['Required Tooling','required_tooling'],['Required Parts','required_parts'],['Required Permits','required_permits']].map(([label,field]) => (
                    <div key={field}>
                      <Label className="text-xs font-medium text-muted-foreground">{label}</Label>
                      <Textarea value={form[field]||''} onChange={e => update(field,e.target.value)} className="mt-1 h-20" />
                    </div>
                  ))}
                </div>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4 pt-2 border-t border-border/50">
                  <Field label="Version" field="version" type="number" form={form} update={update} />
                  <SelectField label="Approval Status" field="approval_status" options={STATUSES} form={form} update={update} />
                  <SelectField label="State Type" field="state_type" options={STATE_TYPES} form={form} update={update} />
                  <Field label="Review Date" field="review_date" type="date" form={form} update={update} />
                  <div className="flex items-center gap-2 pt-5">
                    <Switch checked={form.is_template||false} onCheckedChange={v => update('is_template',v)} />
                    <Label className="text-xs">Save as Template</Label>
                  </div>
                </div>
                <div>
                  <Label className="text-xs font-medium text-muted-foreground">Review Notes</Label>
                  <Textarea value={form.review_notes||''} onChange={e => update('review_notes',e.target.value)} className="mt-1 h-20" />
                </div>
              </div>
            )}
          </div>

          {/* Actions */}
          <div className="flex items-center justify-end gap-3 pt-4 border-t">
            <Button type="button" variant="outline" onClick={onCancel} className="gap-2"><X className="w-4 h-4" /> Cancel</Button>
            <Button type="submit" disabled={isSaving || !form.name} className="gap-2">
              <Save className="w-4 h-4" />
              {process ? 'Update Process' : 'Create Process'}
              {importPreview?.length > 0 && ` + import ${importPreview.length} steps`}
            </Button>
          </div>
        </CardContent>
      </Card>
    </form>
  );
}