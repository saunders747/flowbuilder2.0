import React, { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Edit, Trash2, Copy, ArrowRight, Search, ChevronDown, ChevronRight, Folder, FolderOpen } from 'lucide-react';
import { format } from 'date-fns';
import { cn } from '@/lib/utils';
import { groupProcessesByFleetClass } from '@/hooks/useGroupedProcesses';

const STATUS_STYLES = {
  Draft: 'bg-muted text-muted-foreground',
  'Under Review': 'bg-chart-2/10 text-chart-2 border-chart-2/20',
  'Approved for Trial': 'bg-chart-4/10 text-chart-4 border-chart-4/20',
  'Approved Standard': 'bg-chart-3/10 text-chart-3 border-chart-3/20',
  Superseded: 'bg-destructive/10 text-destructive border-destructive/20',
};

function ProcessCard({ p, onEdit, onDelete, onOpen, onClone }) {
  return (
    <Card className="hover:border-primary/30 transition-colors">
      <CardContent className="p-4">
        <div className="flex items-center justify-between gap-4">
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-2 mb-1">
              <h3 className="font-semibold truncate">{p.name}</h3>
              <Badge variant="outline" className={cn("text-[10px] shrink-0", STATUS_STYLES[p.approval_status || 'Draft'])}>
                {p.approval_status || 'Draft'}
              </Badge>
              {p.is_template && <Badge variant="secondary" className="text-[10px]">Template</Badge>}
            </div>
            <div className="flex items-center gap-4 text-xs text-muted-foreground">
              {p.asset_model && <span>{p.asset_model}</span>}
              {p.service_type && <span>{p.service_type}</span>}
              {p.updated_date && <span>Updated {format(new Date(p.updated_date), 'dd MMM yyyy')}</span>}
            </div>
          </div>
          <div className="flex items-center gap-1 shrink-0">
            <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => onOpen(p)} title="Open in Combination Table">
              <ArrowRight className="w-4 h-4" />
            </Button>
            <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => onEdit(p)} title="Edit metadata">
              <Edit className="w-3.5 h-3.5" />
            </Button>
            <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => onClone(p)} title="Clone process">
              <Copy className="w-3.5 h-3.5" />
            </Button>
            <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive" onClick={() => onDelete(p.id)} title="Delete process">
              <Trash2 className="w-3.5 h-3.5" />
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

export default function ProcessList({ processes, isLoading, onEdit, onDelete, onOpen, onClone }) {
  const [search, setSearch] = useState('');
  const [collapsedGroups, setCollapsedGroups] = useState(new Set());

  const filtered = processes.filter(p =>
    p.name?.toLowerCase().includes(search.toLowerCase()) ||
    p.fleet_class?.toLowerCase().includes(search.toLowerCase()) ||
    p.asset_model?.toLowerCase().includes(search.toLowerCase())
  );

  const groups = groupProcessesByFleetClass(filtered);

  const toggleGroup = (fleetClass) => {
    setCollapsedGroups(prev => {
      const next = new Set(prev);
      next.has(fleetClass) ? next.delete(fleetClass) : next.add(fleetClass);
      return next;
    });
  };

  if (isLoading) {
    return <div className="flex items-center justify-center h-32"><div className="w-6 h-6 border-2 border-primary/30 border-t-primary rounded-full animate-spin" /></div>;
  }

  return (
    <div className="space-y-4">
      <div className="relative max-w-sm">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <Input
          placeholder="Search processes..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="pl-9"
        />
      </div>

      {groups.length === 0 ? (
        <Card><CardContent className="py-12 text-center text-sm text-muted-foreground">No processes found. Create your first one!</CardContent></Card>
      ) : (
        <div className="space-y-3">
          {groups.map(({ fleetClass, processes: procs }) => {
            const isCollapsed = collapsedGroups.has(fleetClass);
            return (
              <div key={fleetClass} className="border border-border rounded-xl overflow-hidden">
                {/* Folder header */}
                <button
                  onClick={() => toggleGroup(fleetClass)}
                  className="w-full flex items-center gap-3 px-4 py-3 bg-muted/40 hover:bg-muted/60 transition-colors text-left"
                >
                  {isCollapsed
                    ? <Folder className="w-4 h-4 text-primary shrink-0" />
                    : <FolderOpen className="w-4 h-4 text-primary shrink-0" />
                  }
                  <span className="font-semibold text-sm flex-1">{fleetClass}</span>
                  <span className="text-xs text-muted-foreground">{procs.length} process{procs.length !== 1 ? 'es' : ''}</span>
                  {isCollapsed
                    ? <ChevronRight className="w-4 h-4 text-muted-foreground shrink-0" />
                    : <ChevronDown className="w-4 h-4 text-muted-foreground shrink-0" />
                  }
                </button>

                {/* Processes inside folder */}
                {!isCollapsed && (
                  <div className="p-3 space-y-2 bg-background">
                    {procs.map(p => (
                      <ProcessCard
                        key={p.id}
                        p={p}
                        onEdit={onEdit}
                        onDelete={onDelete}
                        onOpen={onOpen}
                        onClone={onClone}
                      />
                    ))}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}